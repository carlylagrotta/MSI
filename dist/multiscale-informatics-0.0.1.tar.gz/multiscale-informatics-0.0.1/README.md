# Multi-Scale-Informatics

This is a code to perform multi-scale-informatics optimizations on combustion systems.

Acknowledgements:

The authors gratefully acknowledge support from the Department of Energy Gas Phase Chemical Physics program (DE-SC0019487) and National Science Foundation (CBET-1706252, CBET-1761491).
