# Multi-Scale-Informatics

This is a code to perform multi-scale-informatics optimizations on combustion systems.

